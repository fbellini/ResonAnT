#define DEBUG 0
#define SAVE2LIST 1 //0-all cent and Pt bins, 1-pt bins only, 2- cent bins only 

TString kMacroPath="/Users/bellini/alice/resonances/myKstar/AOD_PbPb2010/output/macros";
TString kNormMacroName="normalizeKStar.C";  
TString kInListName="RsnOut";

enum EpairType { kUnlikePM, kUnlikeMP, kMixingPM, kMixingMP, kLikePP, kLikeMM, knPairTypes};
enum EbackgndType{ kUnlikeSE, kUnlikeME,  kLikeSE, knBackgndTypes};
enum Epart{ kstar, antikstar, knPart};

//TString pairsName[6]={"Unlike1", "Unlike2", "Mixing1", "Mixing2","LikePP", "LikeMM" };
TString pairsName[6]={"UnlikePM", "UnlikeMP", "MixingPM", "MixingMP","LikePP", "LikeMM", };

const Double_t kBigNumber=1E10;
const Double_t kSmallNumber=1E-10;

//define binning in invariant mass
const Double_t invMassInf=0.6;
const Double_t invMassSup=1.5;
const Double_t reductionFactor=1.0;//background reduction factor 
const Double_t normRangeInf=1.3;
const Double_t normRangeSup=1.5;

//define binning in pt
 // Double_t pt[] = {    0.00, 0.40, 0.50, 0.60, 0.70, 0.80, 0.90, 1.00, 1.10, 1.20, 1.30, 1.40, 1.50, 1.60, 1.70, 1.80, 1.90, 2.00, 2.10, 2.20, 2.30, 2.40, 2.50, 2.60, 2.70, 2.80, 2.90, 3.00, 3.20, 3.40, 3.60, 3.80, 4.00, 4.20, 4.40, 4.60, 4.80, 5.00, 5.50, 6.00, 6.50, 7.00, 8.00, 9.00, 10.00 };
Double_t pt[] = {0.00, 0.50, 1.00, 1.50, 2.00, 2.50, 3.00, 4.00, 5.00, 10.00 };

//define binning in centrality
Double_t cent[]={ 0.0, 20.0, 40.0, 60.0, 80.0, 90.0};

Int_t   npt  = sizeof(pt) / sizeof(pt[0]) - 1;
Int_t ncent  = sizeof(cent) / sizeof(cent[0]) - 1;

TString macroDir = "/Users/bellini/alice/macro/kstar";
//---------------------------------------------------------------------------------
void subtractKStarBackgnd(char* infilename="proj_analysisAOD.root"){
  if (!infilename){
    printf("ERROR: invalid file name provided. \n");
    return;
  }
  TFile* fin=TFile::Open(infilename);
  if (!fin) {
    printf("ERROR: invalid or corrupted input file. Exiting.\n");
    return;
  }
  //  fin->ls();  
  TH1D *histosKStar[2][3]; //2 particles * 3 types of pairs
  TString hnameKStar[2][3];
 
#if SAVE2LIST
  TList outlistKstar;
  outlistKstar.SetName("Kstar");
  TList outlistAntiKstar;
  outlistAntiKstar.SetName("AntiKstar");
#endif

  TH1D * hkstarmix[2]={0,0};
  TH1D * hkstarlike[2]={0,0};

  Double_t integralS[2]={0.0,0.0};
  Double_t integralB[2]={0.0,0.0};
  Double_t normFactor[2]={ 1., 1.};

  for (Int_t i=0;i<Epart::knPart;i++){
    //dummy histos initialization
    hkstarmix[i]=new TH1D("hkstarmix","K* after mixing event backgnd subtraction", TMath::Abs(invMassSup-invMassInf)/invMassBinWidth , invMassInf, invMassSup);
    hkstarlike[i]=new TH1D("hkstarlike","K* after like-sign backgnd subtraction", TMath::Abs(invMassSup-invMassInf)/invMassBinWidth , invMassInf, invMassSup);    
  }
  
  TString dummyName;
  TString dummyTitle;
  
#if DEBUG
  TCanvas *dummycanvas=new TCanvas("dummycanvas","dummycanvas",900,600);
  dummycanvas->Divide(2,1);
  dummycanvas->Update();
  TCanvas *dummycanvas2=new TCanvas("dummycanvas2","dummycanvas2",900,600);
  TCanvas *dummycanvas3=new TCanvas("dummycanvas3","dummycanvas2",900,600);
#endif

  /*======================================================================================*/
  //integrate over pt bins
  /*======================================================================================*/
  
  TH1D *histosKStarAllPt[2][3]; //2 particles * 3 types of pairs
  TString hnameKStarAllPt[2][3];
  
  for (Int_t j=0;j<2;j++){
    for (Int_t k=0;k<3;k++){
      TString hn;
      hn.Form("h%i%i",j,k);
      histosKStarAllPt[j][k]=new TH1D(hn,"", TMath::Abs(invMassSup-invMassInf)/invMassBinWidth , invMassInf, invMassSup);
    }
  }

  TH1D * hkstarmixAllPt[2];
  TH1D * hkstarlikeAllPt[2];
  
  TString outfilenameAllPt= "subAllPt_";
  TFile * foutAllPt= new TFile(outfilenameAllPt.Append(infilename),"recreate");
  TTree * normTreeAllPt=new TTree("normTreeAllPt","tree of normalization factors");
  Int_t cBinIDAllPt,partIDAllPt;
  Float_t normFactorEMAllPt, normFactorLSAllPt;
  normTreeAllPt->Branch("partIDAllPt",&partIDAllPt,"partIDAllPt/I");
  normTreeAllPt->Branch("cBinIDAllPt",&cBinIDAllPt,"cBinIDAllPt/I");
  normTreeAllPt->Branch("normFactorEMAllPt",&normFactorEMAllPt,"normFactorEMAllPt/F");
  normTreeAllPt->Branch("normFactorLSAllPt",&normFactorLSAllPt,"normFactorLSAllPt/F");

  for (Int_t i=0;i<Epart::knPart;i++){
    //dummy histos initialization
    hkstarmixAllPt[i]=new TH1D("hkstarmixAllPt","K* after mixing event backgnd subtraction", TMath::Abs(invMassSup-invMassInf)/invMassBinWidth , invMassInf, invMassSup);
    hkstarlikeAllPt[i]=new TH1D("hkstarlikeAllPt","K* after like-sign backgnd subtraction", TMath::Abs(invMassSup-invMassInf)/invMassBinWidth , invMassInf, invMassSup);    
  }
  
  TString hname;
  for (Int_t icentbin=0; icentbin<ncent;icentbin++){    
    cBinIDAllPt=icentbin;
    //LOOP over pairs
    for (Int_t ipair=0; ipair < EpairType::knPairTypes; ipair++){
      
      histosKStarAllPt[ipair%2][ipair/2]->Reset("ICES");      
      //loop on pt bins
      for (Int_t ibin=0;ibin<npt; ibin++){
	hname=DefineInputHistoName(ipair, ibin, icentbin);
	TH1D* htemp2=(TH1D*)fin->Get(hname.Data());
	if (!htemp2) continue;
	histosKStarAllPt[ipair%2][ipair/2]->Add(htemp2);    
#if DEBUG
	printf("Debug: Adding histo %s \n", hname.Data());
#endif	
      }      
    }
    
#if DEBUG
      //K*
      dummycanvas->cd(1);
      // dummycanvas->Clear();
      //dummycanvas->cd(EbackgndType::kUnlikeME);
      histosKStarAllPt[Epart::kstar][EbackgndType::kUnlikeME]->SetLineColor(kBlack);
      histosKStarAllPt[Epart::kstar][EbackgndType::kUnlikeME]->Draw();
      histosKStarAllPt[Epart::kstar][EbackgndType::kUnlikeSE]->SetLineColor(kRed);
      histosKStarAllPt[Epart::kstar][EbackgndType::kUnlikeSE]->Draw("same");
      dummycanvas->Update();
      //   dummycanvas->cd(EbackgndType::kLikeSE);
      histosKStarAllPt[Epart::kstar][EbackgndType::kLikeSE]->SetLineColor(kYellow+2);
      histosKStarAllPt[Epart::kstar][EbackgndType::kLikeSE]->Draw("same");
      dummycanvas->Update();
      
      //anti-K*
      dummycanvas->cd(2);
      // dummycanvas->Clear();
      //dummycanvas->cd(EbackgndType::kUnlikeME);
      histosKStarAllPt[Epart::antikstar][EbackgndType::kUnlikeME]->SetLineColor(kGray+1);
      histosKStarAllPt[Epart::antikstar][EbackgndType::kUnlikeME]->Draw();
      histosKStarAllPt[Epart::antikstar][EbackgndType::kUnlikeSE]->SetLineColor(kBlue);
      histosKStarAllPt[Epart::antikstar][EbackgndType::kUnlikeSE]->Draw("same");
      dummycanvas->Update();
      //   dummycanvas->cd(EbackgndType::kLikeSE);
      histosKStarAllPt[Epart::antikstar][EbackgndType::kLikeSE]->SetLineColor(kGreen+2);
      histosKStarAllPt[Epart::antikstar][EbackgndType::kLikeSE]->Draw("same");
      dummycanvas->Update();
      
#endif
      
      for (Int_t ipart=0;ipart< Epart::knPart; ipart++) { //do the same for K* and anti-K*
      	if (ipart==Epart::kstar) partIDAllPt=1;
	if (ipart==Epart::antikstar) partIDAllPt=-1;
	
	//K* mixing
	hkstarmixAllPt[ipart]->Reset("ICES");
	hkstarmixAllPt[ipart]=(TH1D*)histosKStarAllPt[ipart][EbackgndType::kUnlikeSE]->Clone();
	
	normFactorEMAllPt=GetRangeValuesNormalizationFactor(hkstarmixAllPt[ipart], 
							    histosKStarAllPt[ipart][EbackgndType::kUnlikeME],
							    normRangeInf,
							    normRangeSup );
	printf("***************************** %6.3f \n",normFactorEMAllPt);
	if ( subtractMixingBackgnd( hkstarmixAllPt[ipart], 
				    histosKStarAllPt[ipart][EbackgndType::kUnlikeME],
				    reductionFactor)) {
	  dummyName.Clear();
	  dummyTitle.Clear();
	  
	  if (ipart==Epart::kstar){
	  dummyName.Form("subEM_Data_KStar_ptBinAll_centBin%02i",icentbin);
	  dummyTitle.Form("K* #rightarrow K^{+}#pi^{-} (EM bckgnd) - all p_{T}, %3.0f - %3.0f central",cent[icentbin],cent[icentbin+1] );  
	  hkstarmixAllPt[ipart]->SetLineColor(kRed);	  
	  hkstarmixAllPt[ipart]->SetMarkerColor(kRed);	  
	  hkstarmixAllPt[ipart]->SetMarkerStyle(20);	
	  hkstarmixAllPt[ipart]->SetMarkerSize(0.8);		  
	} else {
	  dummyName.Form("subEM_Data_antiKStar_ptBinAll_centBin%02i",icentbin);
	  dummyTitle.Form("#bar{K*} #rightarrow K^{-}#pi^{+} (EM bckgnd) - all p_{T}, %3.0f - %3.0f central",cent[icentbin],cent[icentbin+1] );   
	  hkstarmixAllPt[ipart]->SetLineColor(kBlue);	  
	  hkstarmixAllPt[ipart]->SetMarkerColor(kBlue);	  
	  hkstarmixAllPt[ipart]->SetMarkerStyle(21);	
	  hkstarmixAllPt[ipart]->SetMarkerSize(0.8);		  
	}
	hkstarmixAllPt[ipart]->SetNameTitle(dummyName,dummyTitle);
#if SAVE2LIST
	// //save to list
	if (ipart==Epart::kstar)
	  outlistKstar.AddLast(hkstarmixAllPt[ipart]);
	else 
	  outlistAntiKstar.AddLast(hkstarmixAllPt[ipart]);
#endif

	foutAllPt->cd();
	hkstarmixAllPt[ipart]->Write();	
      } else {//end check of success of subtraction     
	printf("INFO: subtraction failed!!! CHECK SOURCE!\n");
      }
      
      /*======================================================================================
	K* like sign
	========================================================================================*/
   
     hkstarlikeAllPt[ipart]->Reset("ICES");
     hkstarlikeAllPt[ipart]=(TH1D*)histosKStarAllPt[ipart][EbackgndType::kUnlikeSE]->Clone();
     
     normFactorLSAllPt=GetRangeValuesNormalizationFactor(hkstarlikeAllPt[ipart], 
							  histosKStarAllPt[ipart][EbackgndType::kLikeSE],
							  normRangeInf,
							  normRangeSup);
      
      if ( subtractLikeSignBackgnd( hkstarlikeAllPt[ipart], 
				    histosKStarAllPt[ipart][EbackgndType::kLikeSE],
				    1.0) ){	  
	dummyName.Clear();
	dummyTitle.Clear();
	if (ipart==Epart::kstar) {
	  dummyName=Form("subLS_Data_KStar_ptBinAll_centBin%02i",icentbin);
	  dummyTitle=Form("K* #rightarrow K^{+}#pi^{-} (LS bckgnd) - all p_{T}, %3.0f - %3.0f central",cent[icentbin],cent[icentbin+1] );   
	  hkstarlikeAllPt[ipart]->SetLineColor(kMagenta);	  
	  hkstarlikeAllPt[ipart]->SetMarkerColor(kMagenta);	  
	  hkstarlikeAllPt[ipart]->SetMarkerStyle(24);	
	  hkstarlikeAllPt[ipart]->SetMarkerSize(0.8);		  

	} else {
	  dummyName=Form("subLS_Data_antiKStar_ptBinAll_centBin%02i",icentbin);
	  dummyTitle=Form("K* #rightarrow K^{-}#pi^{+} (LS bckgnd) -all p_{T}, %3.0f - %3.0f central",cent[icentbin],cent[icentbin+1] );   
	  hkstarlikeAllPt[ipart]->SetLineColor(kGreen+2);	  
	  hkstarlikeAllPt[ipart]->SetMarkerColor(kGreen+2);	  
	  hkstarlikeAllPt[ipart]->SetMarkerStyle(25);	
	  hkstarlikeAllPt[ipart]->SetMarkerSize(0.8);		  	  
	}
	hkstarlikeAllPt[ipart]->SetNameTitle(dummyName,dummyTitle);
	
	//save to file
	foutAllPt->cd();
	hkstarlikeAllPt[ipart]->Write();

#if SAVE2LIST	
	//save to list
	if (ipart==Epart::kstar)
	  outlistKstar.AddLast(hkstarlikeAllPt[ipart]);
	else 
	  outlistAntiKstar.AddLast(hkstarlikeAllPt[ipart]);
#endif
	
      } else {//end check of success of subtraction     
	printf("INFO: subtraction failed!!! CHECK SOURCE!\n");
      }
      normTreeAllPt->Fill();
    }//loop over particles
  }//loop over centrality
#endif 
  normTreeAllPt->Write();
  foutAllPt->Close();

  /*======================================================================================*/
  /*======================================================================================*/

  //bin by bin

  /*======================================================================================*/
  /*======================================================================================*/
  TString outfilename= "sub_";
  TFile * fout= new TFile(outfilename.Append(infilename),"recreate");
  TTree * normTree=new TTree("normTree","tree of normalization factors");
  Int_t cBinID,ptBinID,partID;
  Float_t normFactorEM, normFactorLS; 
  normTree->Branch("partID",&partID,"partID/I");
  normTree->Branch("cBinID",&cBinID,"cBinID/I");
  normTree->Branch("ptBinID",&ptBinID,"ptBinID/I");
  normTree->Branch("normFactorEM",&normFactorEM,"normFactorEM/F");
  normTree->Branch("normFactorLS",&normFactorLS,"normFactorLS/F");
  
  //loop over bins
  for (Int_t icentbin=0; icentbin<ncent;icentbin++){
    cBinID=icentbin;
    for (Int_t iptbin=0; iptbin<npt;iptbin++){ 
      ptBinID=iptbin;
      //loop over pairs type
      for (Int_t ipair=0; ipair < EpairType::knPairTypes; ipair++){	
	hnameKStar[ipair%2][ipair/2].Form("Data_%s_ptBin%02i_centBin%02i", pairsName[ipair].Data(),iptbin, icentbin);
	//DefineInputHistoName(ipair, iptbin,icentbin, hnameKStar[ipair%2][ipair/2]);	
	histosKStar[ipair%2][ipair/2]= (TH1D*)fin->Get(hnameKStar[ipair%2][ipair/2]);
	
#if DEBUG
	printf("-------------------------------------------------------- i,j = %i, %i \n", ipair%2,ipair/2);
	printf("Debug: pt bin index = %i ( %5.2f , %5.2f )\n",iptbin, pt[iptbin],pt[iptbin+1]);
	printf("Debug: cent bin index = %i ( %5.2f, %5.2f )\n",icentbin, cent[icentbin],cent[icentbin+1]);
	printf("Debug: histo = histosKstar[%i][%i] = %s \n",  ipair%2, ipair/2, hnameKStar[ipair%2][ipair/2].Data());
#endif	
	if (!histosKStar[ipair%2][ipair/2]) printf("Histo retrieval failed! \n");	  
	
      }//loop on pair types
      
      
#if DEBUG
      //K*
      dummycanvas->cd(1);
      // dummycanvas->Clear();
      //dummycanvas->cd(EbackgndType::kUnlikeME);
      histosKStar[Epart::kstar][EbackgndType::kUnlikeME]->SetLineColor(kBlack);
      histosKStar[Epart::kstar][EbackgndType::kUnlikeME]->Draw();
      histosKStar[Epart::kstar][EbackgndType::kUnlikeSE]->SetLineColor(kRed);
      histosKStar[Epart::kstar][EbackgndType::kUnlikeSE]->Draw("same");
      dummycanvas->Update();
      //   dummycanvas->cd(EbackgndType::kLikeSE);
      histosKStar[Epart::kstar][EbackgndType::kLikeSE]->SetLineColor(kYellow+2);
      histosKStar[Epart::kstar][EbackgndType::kLikeSE]->Draw("same");
      dummycanvas->Update();
      
      //anti-K*
      dummycanvas->cd(2);
      // dummycanvas->Clear();
      //dummycanvas->cd(EbackgndType::kUnlikeME);
      histosKStar[Epart::antikstar][EbackgndType::kUnlikeME]->SetLineColor(kGray+1);
      histosKStar[Epart::antikstar][EbackgndType::kUnlikeME]->Draw();
      histosKStar[Epart::antikstar][EbackgndType::kUnlikeSE]->SetLineColor(kBlue);
      histosKStar[Epart::antikstar][EbackgndType::kUnlikeSE]->Draw("same");
      dummycanvas->Update();
      //   dummycanvas->cd(EbackgndType::kLikeSE);
      histosKStar[Epart::antikstar][EbackgndType::kLikeSE]->SetLineColor(kGreen+2);
      histosKStar[Epart::antikstar][EbackgndType::kLikeSE]->Draw("same");
      dummycanvas->Update();
      
#endif

      for (Int_t ipart=0;ipart< Epart::knPart; ipart++) { //do the same for K* and anti-K*
	if (ipart==Epart::kstar) partID=1;
	if (ipart==Epart::antikstar) partID=-1;
	
	/*======================================================================================
	  K* event mixing
	  ========================================================================================*/	
	
	hkstarmix[ipart]->Reset("ICES");
	//dummy needed not to overwrite the original hist - needed for SE bckgnd
	hkstarmix[ipart]=(TH1D*)histosKStar[ipart][EbackgndType::kUnlikeSE]->Clone();
	
	normFactorEM=GetRangeValuesNormalizationFactor(hkstarmix[ipart], 
						       histosKStar[ipart][EbackgndType::kUnlikeME],
						       normRangeInf,
						       normRangeSup );
	
	if ( subtractMixingBackgnd( hkstarmix[ipart], 
				    histosKStar[ipart][EbackgndType::kUnlikeME],
				    reductionFactor)) {
	  
	  /*
	    hkstarmix[ipart]=(TH1D*) histosKStar[ipart][EbackgndType::kUnlikeSE]->Clone();
	    
	    //Normalize EM backgnd
	    integralS[ipart]= hkstarmix[ipart]->Integral();
	    integralB[ipart]= histosKStar[ipart][EbackgndType::kUnlikeME]->Integral();			   
	    
	    if (integralS[ipart]==0.0){
	    printf("INFO: histogram integral = 0. Skipping normalization.\n");
	    continue;
	    }  	
	    if (integralB[ipart]==0.0){
	    printf("INFO: anti-K* backgnd histogram integral = 0. Skipping normalization.\n");
	    continue;
	    }  	
	    normFactor[ipart]= integralS[ipart]/integralB[ipart];
	    hkstarmix[ipart]->Add(histosKStar[ipart][EbackgndType::kUnlikeME],-reductionFactor*normFactor[ipart]);
	  */
	  dummyName.Clear();
	  dummyName=Form("subEM_%s", histosKStar[ipart][EbackgndType::kUnlikeSE]->GetName());
	  dummyTitle.Clear();
	  if (ipart==Epart::kstar)
	    dummyTitle=Form("K* #rightarrow K^{+}#pi^{-} (EM bckgnd) - %5.2f < pt < %5.2f, %3.0f - %3.0f central",pt[iptbin],pt[iptbin+1],cent[icentbin],cent[icentbin+1] );   	
	  else 
	    dummyTitle=Form("#bar{K*} #rightarrow K^{-}#pi^{+} (EM bckgnd) - %5.2f < pt < %5.2f, %3.0f - %3.0f central",pt[iptbin],pt[iptbin+1],cent[icentbin],cent[icentbin+1] );   
	
	  hkstarmix[ipart]->SetNameTitle(dummyName,dummyTitle);
#if SAVE2LIST
	  //save to list
	  if (ipart==Epart::kstar){
	    outlistKstar.AddLast(hkstarmix[ipart]);
	    printf("Debug: saving MIX object %s  -> found in list with name %s \n",dummyName.Data(), outlistKstar.Last()->GetName());		    
	  } else { 
	    outlistAntiKstar.AddLast(hkstarmix[ipart]);
	    printf("Debug: saving MIX object %s  -> found in list with name %s \n",dummyName.Data(), outlistAntiKstar.Last()->GetName());
	  }
	 
#endif	

	  fout->cd();
	  hkstarmix[ipart]->Write();
	  
#if DEBUG      
	  dummycanvas2->cd();
	  hkstarmix[ipart]->Draw();
	  dummycanvas2->Update();
#endif
	}//end check success of subtraction
	
	/*======================================================================================
	  K* like sign
	  ========================================================================================*/
	hkstarlike[ipart]->Reset("ICES");
	hkstarlike[ipart]=(TH1D*) histosKStar[ipart][EbackgndType::kUnlikeSE]->Clone();

	normFactorLS=GetRangeValuesNormalizationFactor(hkstarlike[ipart], 
							    histosKStar[ipart][EbackgndType::kLikeSE],
							    normRangeInf,
							    normRangeSup );


	if ( subtractLikeSignBackgnd( hkstarlike[ipart], 
				      histosKStar[ipart][EbackgndType::kLikeSE],
				      1.0) ){	  
	  dummyName.Clear();
	  dummyName=Form("subLS_%s", histosKStar[ipart][EbackgndType::kUnlikeSE]->GetName());
	  dummyTitle.Clear();
	  if (ipart==Epart::kstar)
	    dummyTitle=Form("K* #rightarrow K^{+}#pi^{-} (LS bckgnd) - %5.2f < pt < %5.2f, %3.0f - %3.0f central",pt[iptbin],pt[iptbin+1],cent[icentbin],cent[icentbin+1] );   
	  else 
	    dummyTitle=Form("K* #rightarrow K^{-}#pi^{+} (LS bckgnd) - %5.2f < pt < %5.2f, %3.0f - %3.0f central",pt[iptbin],pt[iptbin+1],cent[icentbin],cent[icentbin+1] );   	  
	  hkstarlike[ipart]->SetNameTitle(dummyName,dummyTitle);
	  
	  //save to file
	  fout->cd();
	  hkstarlike[ipart]->Write();
	  
#if SAVE2LIST
	  //save to list
	  if (ipart==Epart::kstar)
	    outlistKstar.AddLast(hkstarlike[ipart]);
	  else 
	    outlistAntiKstar.AddLast(hkstarlike[ipart]);
	  #if DEBUG   
	  if (ipart==Epart::kstar)	
	    printf("Debug: saving LIKE object %s -> found in list with name %s \n", dummyName.Data(), outlistKstar.Last()->GetName());
	  else
	    printf("Debug: saving LIKE object %s -> found in list with name %s \n", dummyName.Data(), outlistAntiKstar.Last()->GetName());    
#endif  
#endif
	  
	} else {//end check of success of subtraction     
	  printf("INFO: subtraction failed!!! CHECK SOURCE!\n");
	}
	normTree->Fill();
      }//loop on K*
    }//loop on pt bins
  }//loop on cent bins

  
#if SAVE2LIST
  fout->cd();
  outlistKstar.Write();
  outlistAntiKstar.Write();
#endif 

  fout->cd();
  normTree->Write();
  fout->Close();

  printf("*************************************************************************************************\n****************************************  SUMMARY   *********************************************\n**************************************************************************************************\n");
  printf("INFO: analysis successful:\n
                subtraction results bin by bin -> saved in file ______________ %s\n
	        tree with norm factors bin by bin -> saved in file ______________ %s\n
                subtraction results integrated over all pT bins -> saved in file ______________ %s\n
	        tree with norm factors integrated over all pT bins -> saved in file ______________%s\n",
	 fout->GetName(), fout->GetName(), /*foutAllPt->GetName(),foutAllPt->GetName()*/);
  fin->Close();
  return;  
}

//---------------------------------------------------------------------------------
TString DefineInputHistoName(Int_t ipair=-1, Int_t iptbin=-1, Int_t icentbin=-1)
{

  //builds histogram name according to fixed pattern
  if ((ipair<0) ||(iptbin<0) ||(icentbin<0) ){
    printf("InputHistoName::ERROR - Invalid bin chosen. \n");
    return;
  }
  TString name="";
  //name.Clear();
  name.Form("Data_%s_ptBin%02i_centBin%02i", pairsName[ipair].Data(),iptbin, icentbin);
#if DEBUG 
 printf("Histo name defined: %s\n",name.Data());
#endif
  return name;
}

//---------------------------------------------------------------------------------
void IntegrateAllPtBins( TH1D* hinteg,TFile * fin, Int_t ipair, Int_t icentbin=-1){
  
  if (!fin){
    printf("IntegrateAllPtBins::ERROR - Invalid source file. \n");
    return;
  }
  
  if ((ipair<0) ||(icentbin<0) ){
    printf("IntegrateAllPtBins::ERROR - Invalid bin chosen. \n");
    return;
  }
  if (!hinteg) return;
  // hinteg->Clear();
  TString hname;
  TH1D* htemp;
  for (Int_t ibin=0;ibin<npt; ibin++){
    hname=DefineInputHistoName(ipair, ibin, icentbin);
    htemp=(TH1D*)fin->Get(hname.Data());
    if (!htemp) continue;
    hinteg->Add(htemp);    
#if DEBUG
    printf("Debug: Adding histo %s \n", hname.Data());
#endif	
  }
  return;
}

//---------------------------------------------------------------------------------
/*
void RetrieveHistosInPtCentBin(TFile * fin, Int_t iptbin=-1, Int_t icentbin=-1, TH1D * histosKStar[][]){
  
  if (!fin) {
    printf("RetrieveHistosInPtCentBin::ERROR - Invalid input file: cannot retrieve source data.\n");
    return;
  }
  
  if ( (iptbin<0) ||(icentbin<0) ){
    printf("RetrieveHistosInPtCentBin::ERROR - Invalid bin chosen. \n");
    return;
  }
  
  TString hnameKStar[2][3];
  
  //loop over pairs type
  for (Int_t ipair=0;ipair < EpairType::knPairTypes; ipair++){	
    
    DefineInputHistoName(ipair, iptbin,icentbin, hnameKStar[ipair%2][ipair/2]);
    histosKStar[ipair%2][ipair/2]=(TH1D*)fin->Get(hnameKStar[ipair%2][ipair/2].Data());

#if DEBUG
    printf("-------------------------------------------------------- i,j = %i, %i \n", ipair%2,ipair/2);
    printf("Debug: pt bin index = %i ( %5.2f , %5.2f )\n",iptbin, pt[iptbin],pt[iptbin+1]);
    printf("Debug: cent bin index = %i ( %5.2f, %5.2f )\n",icentbin, cent[icentbin],cent[icentbin+1]);
    printf("Debug: histo = histosKstar[%i][%i] = %s \n",  ipair%2, ipair/2, hnameKStar[ipair%2][ipair/2].Data());
    if (!histosKStar[ipair%2][ipair/2]) 
      printf("Histo retrieval failed! \n");	  
#endif	
    
  }//loop on pair types
  
  return;
}



*/
//---------------------------------------------------------------------------------
TH1D* subtractMixingBackgnd(TH1D* hist=NULL, TH1D* hist2=NULL, Float_t factor=1.0){
  
  if ((!hist)||(!hist2)){
    printf("subtractMixingBackgnd - ERROR: invalid histogram address passed to subtraction function\n");
    return 0x0;
  }
  
  TH1D *backgnd=new TH1D(); 
  if (factor>0.0){
    //  backgnd=(TH1D*) normalize2Integral(hist2, hist, normFactor);    
    backgnd=(TH1D*)normValuesInterval(hist2, hist, 1.1, 1.5, factor);
  } else {
    backgnd=(TH1D*)hist2->Clone(); 
  }
  // backgnd->SaveAs(Form("%s.root",backgnd->GetName()));
  // hist->SaveAs(Form("%s.root",hist->GetName()));
  return subtractBackgnd(hist, backgnd);  
}

//---------------------------------------------------------------------------------
TH1D* subtractLikeSignBackgnd(TH1D* hist=NULL, TH1D* hist2=NULL, Float_t factor=1.0){
  
  if ((!hist)||(!hist2)){
    printf("subtractLikeSignBackgnd - ERROR: invalid histgram address passed to subtraction function\n");
    return 0x0;
  }  
  /*
    use if not normalize
  if (factor!=0.0) hist2->Scale(factor);
  return subtractBackgnd(hist, hist2);  
  */
  TH1D *backgnd=new TH1D(); 
  if (factor>0.0){
    //  backgnd=(TH1D*) normalize2Integral(hist2, hist, normFactor);    
    backgnd=(TH1D*)normValuesInterval(hist2, hist, 1.1, 1.5, factor);
  } else {
    backgnd=(TH1D*)hist2->Clone(); 
  }
  // backgnd->SaveAs(Form("%s.root",backgnd->GetName()));
  // hist->SaveAs(Form("%s.root",hist->GetName()));
  return subtractBackgnd(hist, backgnd);  
  
}

//---------------------------------------------------------------------------------
TH1D* subtractBackgnd(TH1D* hist=NULL, TH1D* hist2=NULL){
  //hist - hist2
  if ((!hist)||(!hist2)){
    printf("subtractBackgnd - ERROR: invalid histgram address passed to base subtraction function\n");
    return 0x0;
  }
  
  Int_t nbins=hist->GetXaxis()->GetNbins();
  Int_t nbinsRef=hist2->GetXaxis()->GetNbins();
  
  if (nbins!=nbinsRef){
    printf("subtractBackgnd - ERROR: histgrams have different binning. Doing nothing.\n");
    return 0x0;    
  }
  
  hist->Add(hist2,-1);
  return hist;
}

//---------------------------------------------------------------------------------
TH1D* normalize2Integral(TH1D* hist=NULL, TH1D*histRef=NULL, Double_t factor=1.){
  
  if ((!hist)||(!histRef)){
    printf("normalize2Integral - ERROR: invalid histogram address passed to normalization function\n");
    return 0;
  }
  
  Int_t nbins=hist->GetXaxis()->GetNbins();
  Int_t nbinsRef=histRef->GetXaxis()->GetNbins();
  
  if (nbins!=nbinsRef){
    printf("normalize2Integral - ERROR: histgrams have different binning. Doing nothing.\n");
    return 0;    
  }
  
  TH1D * cloneH = (TH1D*) hist->Clone();
  Double_t integralS= histRef->Integral();
  Double_t integralB= hist->Integral();
  
  if (integralS==0){
    printf("normalize2Integral - INFO: signal + backgnd histogram integral = 0. Skipping normalization.\n");
    return 0;
  }
  
  if (integralB==0){
    printf("normalize2Integral - INFO: backgnd histogram integral = 0. Skipping normalization.\n");
    return 0;
  }
  
  if (factor<=0) factor=1.;
  Double_t normFactor= factor*integralS/integralB;
  cloneH->Scale(normFactor);
  return cloneH;
}

//---------------------------------------------------------------------------------
Float_t GetRangeValuesNormalizationFactor(TH1D* hist=NULL, TH1D* histRef=NULL, Double_t valueMin=1.3, Double_t valueMax=1.5){
  
  /*
    estimate normalization factor to be used on hist
    by using histRef as reference 
    in *values* range given by valueMin - valueMax
    
  */

  if ((!hist)||(!histRef)){
    printf("GetRangeValuesNormalizationFactor - ERROR: invalid histgram address passed to normalization function\n");
    return 0;
  }
  
  Int_t nbins=hist->GetXaxis()->GetNbins();
  Int_t nbinsRef=histRef->GetXaxis()->GetNbins();
  
  if (nbins!=nbinsRef){
    printf("GetRangeValuesNormalizationFactor - ERROR: histgrams have different binning. Doing nothing.\n");
    return 0;    
  }
  
  Int_t ibinmin,ibinmax;
  
  if ((valueMin<=kSmallNumber) || (valueMin>=valueMax)) {
    valueMin = hist->GetXaxis()->GetBinLowEdge(1);
    ibinmin=1;
    printf("GetRangeValuesNormalizationFactor - INFO:  min value used for normalization range as default.\n");
  } else {
    ibinmin= 1 + ( valueMin-(hist->GetXaxis()->GetBinLowEdge(1)) )/invMassBinWidth;
  } 
  
  if ((valueMax>=kBigNumber) || (valueMax<valueMin)) {
    valueMax = hist->GetXaxis()->GetBinUpEdge(nbins);
    ibinmax=nbins;
    printf("GetRangeValuesNormalizationFactor - INFO:  max value used for normalization range as default.\n");  
  } else {    
    ibinmax = nbins - ( (hist->GetXaxis()->GetBinLowEdge(nbins)) - valueMax )/invMassBinWidth;  
  }
  
  printf("--------------- Normalizing histogram in interval [ %5.2f - %5.2f ]\n",valueMin,valueMax);
  printf("                corresponding to (x-axis) bin interval [ %i - %i ]\n",ibinmin,ibinmax);
  
  Double_t integralS= histRef->Integral(ibinmin,ibinmax);
  Double_t integralB= hist->Integral(ibinmin,ibinmax);
  
  if (integralS==0){
    printf("GetRangeValuesNormalizationFactor - INFO: reference histogram integral = 0. Skipping normalization.\n");
    return 0;
  }
  if (integralB==0){
    printf("GetRangeValuesNormalizationFactor - INFO: histogram to be normalized has integral = 0. Skipping normalization.\n");
    return 0;
  }
  
  Double_t normFactor= integralS/integralB;
  printf("GetRangeValuesNormalizationFactor - INFO: Normalization factor estimate = %6.3f\n",normFactor);
  return normFactor;
  
}

//---------------------------------------------------------------------------------
TH1D* normValuesInterval(TH1D* hist=NULL, TH1D* histRef=NULL, Double_t valueMin=1.1, Double_t valueMax=1.5, Double_t factor=1.){
  
  if ((!hist)||(!histRef)){
    printf("normValuesInterval - ERROR: invalid histgram address passed to normalization function\n");
    return 0;
  }
    printf("normValuesInterval - INFO: Normalizing background in IM interval [ %5.2f - %5.2f ]\n",valueMin,valueMax);
  
  TH1D * cloneH = (TH1D*) hist->Clone();  
  Double_t normFactor= GetRangeValuesNormalizationFactor(hist,histRef,valueMin,valueMax);
  printf("normValuesInterval - INFO: normalized histo %s with norm factor = (norm)%6.3f * (custom)%6.3f = (tot) %6.3f\n",cloneH->GetName(),normFactor,factor,normFactor*factor);  
  if (factor<=0) factor=1.;
  normFactor=normFactor*factor;
  cloneH->Scale(normFactor);
  return cloneH;
  
}

//---------------------------------------------------------------------------------
TH1D* normValuesInterval_old(TH1D* hist=NULL, TH1D* histRef=NULL, Double_t valueMin=1.1, Double_t valueMax=1.5, Double_t factor=1.){
  
  if ((!hist)||(!histRef)){
    printf("ERROR: invalid histgram address passed to normalization function\n");
    return 0;
  }
  
  Int_t nbins=hist->GetXaxis()->GetNbins();
  Int_t nbinsRef=histRef->GetXaxis()->GetNbins();
  
  if (nbins!=nbinsRef){
    printf("ERROR: histgrams have different binning. Doing nothing.\n");
    return 0;    
  }
  
  Int_t ibinmin=-1,ibinmax=-1;

  if ((valueMin<=kSmallNumber) || (valueMin>=valueMax)) {
    valueMin = hist->GetXaxis()->GetBinLowEdge(1);
    ibinmin=1;
    printf("INFO:  min value used for normalization range as default.\n");
  } else {
    ibinmin= 1 + ( ( valueMin - (hist->GetXaxis()->GetBinLowEdge(1)) ) / invMassBinWidth );
  } 
  
  if ((valueMax>=kBigNumber) || (valueMax<valueMin)) {
    valueMax = hist->GetXaxis()->GetBinUpEdge(nbins);
    ibinmax=nbins;
    printf("INFO:  max value used for normalization range as default.\n");  
  } else {    
    ibinmax = nbins - ( (hist->GetXaxis()->GetBinLowEdge(nbins)) - valueMax )/invMassBinWidth;  
  }
  
  printf("--------------- Normalizing background in IM interval [ %5.2f - %5.2f ]\n",valueMin,valueMax);
  printf("                corresponding to IM (x-axis) bins [ %i - %i ]\n",ibinmin,ibinmax);
  
  TH1D * cloneH = (TH1D*) hist->Clone();
  Double_t integralS= histRef->Integral(ibinmin,ibinmax);
  Double_t integralB= hist->Integral(ibinmin,ibinmax);
  
  if (integralS==0){
    printf("INFO: signal + backgnd histogram integral = 0. Skipping normalization.\n");
    return 0;
  }
  if (integralB==0){
    printf("INFO: backgnd histogram integral = 0. Skipping normalization.\n");
    return 0;
  }
  
  if (factor<=0) factor=1.;
  Double_t normFactor= factor*integralS/integralB;
  printf("normValuesInterval - INFO: normalized histo %s with norm factor = %6.3f\n",cloneH->GetName(),normFactor);
  cloneH->Scale(normFactor);
  return cloneH;
  
}
//-----------------------------------------------------------------------
Double_t BestNormalization(TH1D *hSig, TH1D *hBg, Double_t normMin, Double_t normMax, Double_t normStep, Int_t firstBin, Int_t lastBin)
{
//
// search best factor which leaves all subtractions positive within error
//
   Double_t norm, bestNorm = normMin;
   Double_t min, bestMin  = 1E20;
   for (norm = normMax; norm >= normMin; norm -= normStep) {
      TH1D *htmp = (TH1D*)hSig->Clone("tmp");
      htmp->Add(hBg, -norm);
      min = 1E20;
      for (Int_t k = firstBin; k <= lastBin; k++) {
         Double_t y  = htmp->GetBinContent(k);
         if (htmp->GetBinError(k) < 1E-6) continue;
         y -= htmp->GetBinError(k);
         if (y < min) min = y;
      }
      if (min < 0.0)  
         continue;
      else if (min < bestMin) {
         bestMin  = min;
         bestNorm = norm;
      }
   }
   Double_t IntS=htmp->Integral(firstBin, lastBin);
   Double_t IntB = hBg->Integral(firstBin, lastBin);
   Printf("Normalization: best -> intS = %f, intB = %f, norm = %8.4f", IntS, IntB, bestNorm);
   return bestNorm;
}
