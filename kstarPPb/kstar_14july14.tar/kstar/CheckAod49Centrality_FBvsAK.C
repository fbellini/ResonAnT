void CheckAod49Centrality()
{
  gROOT->LoadMacro("GetNormalizationFactors.C");  

  //Double_t * fb_fact;
  Double_t fb_fact_copy[9];
   for (Int_t i=0; i<9; i++){
     fb_fact_copy[i]=0.0;
   }
  GetNormalizationFactors( fb_fact_copy,"FB_centrality.root","hCentralityV0patch");
  
  //Double_t * rsn_fact =
  Double_t rsn_fact_copy[9];
  for (Int_t i=0; i<9; i++){
    rsn_fact_copy[i]=0.0;
   }
  GetNormalizationFactors(rsn_fact_copy,"Rsn_centrality.root","RSN_eventMult");
  for (Int_t i=0; i<9; i++){
    Printf("FB = %10.0f    Rsn = %10.0f      FB-RSN = %10.0f   (%f %)",
	   fb_fact_copy[i], rsn_fact_copy[i],
	   fb_fact_copy[i] - rsn_fact_copy[i],
	   (fb_fact_copy[i] - rsn_fact_copy[i])*100./fb_fact_copy[i]);
  }
}

void CompareAK_Aod49Centrality()
{
  gROOT->LoadMacro("GetNormalizationFactors.C");  

  //Double_t * fb_fact;
  Double_t fb_fact_copy[13], fb_rescaled[13];
   for (Int_t i=0; i<13; i++){
     fb_fact_copy[i]=0.0;
     fb_rescaled[i]=0.0;
   }
  GetNormalizationFactors( fb_fact_copy,"FB_centrality.root","hCentralityV0patch");
  
  //Double_t * rsn_fact =
  Double_t rsn_fact_copy[13];
  for (Int_t i=0; i<13; i++){
    rsn_fact_copy[i]=0.0;
   }
  GetNormalizationFactors(rsn_fact_copy,"ak_centrality.root","RSN_eventMult");
  for (Int_t i=0; i<13; i++){
    Double_t ak_acc= 1.1761064e+07.;
    Double_t fb_acc= 4425475.;
    Double_t evt_scale = fb_acc/ak_acc;
    fb_rescaled[i]= fb_fact_copy[i]/evt_scale;
    Printf("FB = %10.0f  FBrescaled = %10f  AK = %10.0f   FBr-AK = %10.0f =>  (FBr-AK)*100/AK = %f (percentage))",
	   fb_fact_copy[i], fb_rescaled[i], rsn_fact_copy[i],
	   fb_rescaled[i] - rsn_fact_copy[i],
	   (fb_rescaled[i] - rsn_fact_copy[i])*100./rsn_fact_copy[i]);    //fb_rescaled[i]);
  }
}
