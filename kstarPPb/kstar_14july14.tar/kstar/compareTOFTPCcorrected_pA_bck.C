/***** files with spectra with stat. uncert. only

       TString fileTOF="./pAexpress215-216/TOF_ANA/ana2s/fit_bestRange_fixedW/CORRECTED_best_fit_poly2.root",
       TString fileTPC="./pAexpress215-216/TPC_ANA/ana2s/fit_bestRange_fixedW/CORRECTED_best_fit_poly2.root",

******/

void compareTOFTPCcorrected_pA(TString fileTOF="./pAexpress215-216/TOF_ANA/ana2s/FINAL/finalWsyst_24set13_0.root",
			       TString fileTPC="./pAexpress215-216/TPC_ANA/ana2s/FINAL/finalWsyst_24set13_0.root",
			       TString suffix = "")
{
  TFile * fout = new TFile(Form("compareTPCTOF_pA%s.root",suffix.Data()),"recreate");
  for (Int_t j=0;j<5;j++){
    fileTOF.ReplaceAll("_0.root", Form("_%i.root",j))
    fileTPC.ReplaceAll("_0.root", Form("_%i.root",j))
    TH1D* h = (TH1D*)compareTOFTPCcorrected_cent(fileTOF.Data(),fileTPC.Data(),j, 1);
    fout->cd();
    h->Write();
  }
  return;
}


TH1D* compareTOFTPCcorrected_cent(TString fileTOF="./pAexpress215-216/TOF_ANA/ana2s/FINAL/finalWsyst_24set13_0.root",
				  TString fileTPC="./pAexpress215-216/TPC_ANA/ana2s/FINAL/finalWsyst_24set13_0.root",
				  Int_t centBin=0,
				  Bool_t useErrDiff=0){
  
  TFile* ftpc = TFile::Open(fileTPC.Data(),"read");
  TFile* ftof = TFile::Open(fileTOF.Data(),"read");

  //color TOF spectra
  Color_t color[2][6]={kTeal+3, kSpring+5, kBlue-3, kCyan-3, kAzure-6, kBlack, //tpc
		       kRed+2, kOrange+6, kViolet-6, kMagenta, kBlue+2, kBlack}; //tof
  Int_t marker[2][6]={21, 22, 23, 34, 33, 20, //tpc
		      25, 26, 32, 28, 27, 24}; //tof

  Double_t pt[] = { 0.0, 0.3, 0.5, 1.0, 1.5, 2.0, 2.5, 3.0, 3.5, 4.0, 4.5, 5.0, 6.0, 7.0, 8.0, 10.00 };
  TString tofhname = Form("hTOFCorrected_%i", centBin); 
  TString tpchname = Form("hTPCCorrected_%i",centBin);
  
  TH1F* htof = (TH1F*)ftof->Get(tofhname.Data());
  TH1F* htpc =(TH1F*)ftpc->Get(tpchname.Data());
 
  if (!htof){
    Printf("Tof data unaccessible");
    return;
  }
  if (!htpc){
    Printf("Tpc data unaccessible");
    return;
  }

  if (!(htof->GetXaxis()->GetNbins()==htpc->GetXaxis()->GetNbins())) 
    Printf("::::Warning: TPC and TOF have different number of bins");
  TH1D * ratioD = (TH1D*)htof->Clone(Form("ratioD_%i",centBin));
  ratioD->Reset();
  
  for (Int_t ibin=1;ibin<htof->GetXaxis()->GetNbins()+1; ibin++){
    Double_t x1,x2, e1,e2;
    x1=htof->GetBinContent(ibin);
    e1=htof->GetBinError(ibin);
    x2=htpc->GetBinContent(ibin);
    e2=htpc->GetBinError(ibin);
    Double_t sumE2 = TMath::Sqrt(e1*e1+e2*e2);
    Double_t diffE2 = diff2(e1,e2);
    if (x2==0.0) ratioD->SetBinContent(ibin, 0.0);
    else ratioD->SetBinContent(ibin, x1/x2);
    ratioD->SetBinError(ibin, diffE2);
  }

  gROOT->LoadMacro("${ASD}/GetPlotRatio.C");
  TString centLabel=Form(" %i-%i",centBin*20,(centBin+1)*20);
  TH1D * ratio = (TH1D *) GetPlotRatio(htof,htpc, kTRUE,Form("TOF %s",centLabel.Data()),Form("TPC %s",centLabel.Data()),"corrected spectra", 0, 0, Form("tof2tpc_cent%i.png",centBin), 1.0, 8.0);
  ratio->SetNameTitle (Form("tof2tpc_%i",centBin),Form("TOF/TPC %i", centBin*20,(centBin+1)*20));
  ratio->SetLineColor(color[1][centBin]+2);
  ratio->SetMarkerColor(color[1][centBin]+2);
  ratio->SetMarkerStyle(marker[1][centBin]);
  if (useErrDiff) return ratioD;
  else return ratio;
}

Double_t diff2(Double_t x1, Double_t x2)
{
  Double_t dummy=0.0;
  if (x1 >= x2){
    dummy = x1*x1-x2*x2;
  } else {
    dummy = x2*x2-x1*x1;
  }
  return TMath::Sqrt(dummy);	
}
