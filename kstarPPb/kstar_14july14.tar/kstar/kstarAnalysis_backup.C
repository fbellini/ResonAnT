void kstarAnalysis(Int_t ipt=-1, Int_t icent=-1,Bool_t useEM=0){
  
  Bool_t isRebin=0;
  Bool_t addAntiKstar=1;
  TFile * f= TFile::Open("proj_analysisAOD.root");
  gROOT->LoadMacro("subtractKStarBackgnd.C");
  //f->ls();
  TString fout_name;
  if (useEM) fout_name="subEM_proj_analysisAOD.root";
  else fout_name="subLS_proj_analysisAOD.root";

  TFile * fout = new TFile(fout_name.Data(),"recreate");
  Bool_t nextBin ;
    
  for (Int_t icentbin=0;icentbin<5;icentbin++){
    TCanvas * cdisplaycent = new TCanvas(Form("cent_%20i",icentbin),Form("cent_%20i",icentbin),800,600);
    cdisplaycent->Divide(3,3);
    for (Int_t iptbin=0;iptbin<9;iptbin++){
      
      TString hs1_name=Form("Data_UnlikePM_ptBin%02i_centBin%02i",iptbin,icentbin);
      TString hs2_name=Form("Data_UnlikeMP_ptBin%02i_centBin%02i",iptbin,icentbin);
      TString hb1em_name=Form("Data_MixingPM_ptBin%02i_centBin%02i",iptbin,icentbin);
      TString hb2em_name=Form("Data_MixingMP_ptBin%02i_centBin%02i",iptbin,icentbin);
      TString hb1ls_name=Form("Data_LikePP_ptBin%02i_centBin%02i",iptbin,icentbin);
      TString hb2ls_name=Form("Data_LikeMM_ptBin%02i_centBin%02i",iptbin,icentbin);
      
      TH1D * hs1 = (TH1D*) f->Get(hs1_name.Data())->Clone();
      Printf("Signal+background SE kstar: %s",hs1_name.Data());
   
      TH1D * hs2 = (TH1D*) f->Get(hs2_name.Data())->Clone();
      Printf("Signal+background SE antikstar: %s",hs2_name.Data());

      TH1D * hs = (TH1D*) hs1->Clone();
      if (addAntiKstar)	hs->Add(hs2);
      
      TCanvas * cdisplay = new TCanvas("cdisplay","cdisplay",800,600);
      cdisplay->Divide(2,1);
      
      if (useEM){
	/* 
	   background subtraction formula: sub = s-b
	   s = ls_pm + ls_mp       (only if K*+anti-K* is enabled, otherwise only one of the two ls)
	   b = (em_pm + em_mp)*0.5
	*/
	TH1D * hb1 = (TH1D*) f->Get(hb1em_name.Data())->Clone();
	Printf("Background em 1: %s",hb1em_name.Data());
	TH1D * hb2 = (TH1D*) f->Get(hb2em_name.Data())->Clone();
	Printf("Background em 2: %s",hb2em_name.Data());
	TH1D * hb =  (TH1D*)hb1->Clone();
	hb->Add(hb2,1);
	hb->Scale(0.5);
	//draw
	cdisplay->cd(1);
	hs->Draw();
	//save copy of original hb to hb_bis
	TH1D * hb_bis = (TH1D*)hb->Clone(); 
	//normalize hb
	TH1D * hb_norm = normValuesInterval(hb, hs, 1.1, 1.5, 1.);
	hb_norm->SetName(Form("norm_%s",hb->GetName()));
	hb_norm->Draw("same");
	//rebin 
	if (isRebin) {
	  hs->Rebin(2);
	  hb->Rebin(2);
	}
	//subtract
	// TH1D * sub_em =(TH1D*)subtractMixingBackgnd(hs,hb,1.0);
	TH1D * sub_em =(TH1D*) subtractBackgnd(hs,hb_norm);
	sub_em->SetName(Form("sub_%s",hb_norm->GetName()));
	HistoMakeUp(sub_em);   
	TH1D * hb_bis = (TH1D*)hb->Clone();
	cdisplay->cd(2);
	sub_em->Draw();
	cdisplaycent->cd(iptbin+1);
	sub_em->Draw();
	//write on file
	fout->cd();
	sub_em->Write();

      } else {
	/* 
	   background subtraction formula: sub = s-b
	   s = ls_pm + ls_mp       (only if K*+anti-K* is enabled, otherwise only one of the two ls)
	   b = (ls_pp + ls_mm)
	*/
	TH1D * hb1 = (TH1D*) f->Get(hb1ls_name.Data())->Clone();
	Printf("Background ls 1: %s",hb1ls_name.Data());
	TH1D * hb2 = (TH1D*) f->Get(hb2ls_name.Data())->Clone();
	Printf("Background ls 2: %s",hb2ls_name.Data());
	TH1D * hb = (TH1D*) hb1->Clone();
	hb->Add(hb2,1);
	//hb->Scale(0.5);
	//draw
	cdisplay->cd(1);
	hs->Draw();
	//save copy of original hb to hb_bis
	TH1D * hb_bis = (TH1D*)hb->Clone(); 
	//normalize hb
	TH1D * hb_norm = normValuesInterval(hb, hs, 1.1, 1.5, 1.);
	hb_norm->SetName(Form("norm_%s",hb->GetName()));
	hb_norm->Draw("same");
	//rebin 
	if (isRebin) {
	  hs->Rebin(2);
	  hb->Rebin(2);
	}
	//TH1D * sub_ls =(TH1D*) subtractLikeSignBackgnd(hs,hb,-1.0);
	TH1D * sub_ls =(TH1D*)subtractBackgnd(hs,hb_norm);
	sub_ls->SetName(Form("sub_%s",hb_norm->GetName()));
	HistoMakeUp(sub_ls);
	cdisplay->cd(2);
	sub_ls->Draw(); // keep -1 not to normalize
	cdisplaycent->cd(iptbin+1);
	sub_ls->Draw();
       //write on file
	fout->cd();
	sub_ls->Write(); 
      }
    }
    fout->cd();
    cdisplaycent->Write();
    cdisplaycent->SaveAs(Form("centrality%02i_LS_subCanvas.png",icentbin));
    // cdisplay->Update();
    // cout << "Continue? (1/0)" << endl;
    // cin >> nextBin;
    //  switch (nextBin) 
    //    {
    //    case 1:
    //  	 continue;
    //    default:
    //  	 return;
    //    }
  }
 return;
}

/*****************************************/
void HistoMakeUp(TH1D*histo){
  if (!histo) return;
  TString hname = Form("%s",histo->GetName());

  // histo->Rebin(2);

  TAxis * xaxis = (TAxis*)histo->GetXaxis();
  xaxis->SetTitle("M_{inv} (GeV/c^{2})");

  TAxis * yaxis = (TAxis*)histo->GetYaxis();
  yaxis->SetTitle("pairs");

  Color_t color;
  if (hname.Contains("Mixing"))
    color = kRed;
  if (hname.Contains("Like"))
    color = kAzure-4;
  if (hname.Contains("Like") && hname.Contains("norm"))
    color = kGreen+1;
  
  histo->SetLineColor(color);
  histo->SetMarkerColor(color);
  return;
}

/*****************************************/
void showDistributionsPerCentBin(Int_t icentbin=-1,Bool_t useEM=0){
  
  TFile * f= TFile::Open("proj_analysisAOD.root");
  gROOT->LoadMacro("subtractKStarBackgnd.C");
  
  TCanvas * cdisplay = new TCanvas("cdisplay","cdisplay",900,700);
  cdisplay->Divide(3,3);
  
  for (Int_t iptbin=0;iptbin<9;iptbin++){
    TString hs_name=Form("Data_UnlikePM_ptBin%02i_centBin%02i",iptbin,icentbin);
    TString hb1em_name=Form("Data_MixingPM_ptBin%02i_centBin%02i",iptbin,icentbin);
    TString hb2em_name=Form("Data_MixingMP_ptBin%02i_centBin%02i",iptbin,icentbin);
    TString hb1ls_name=Form("Data_LikePP_ptBin%02i_centBin%02i",iptbin,icentbin);
    TString hb2ls_name=Form("Data_LikeMM_ptBin%02i_centBin%02i",iptbin,icentbin);
     
    TH1D * hs = (TH1D*) f->Get(hs_name.Data())->Clone();
    Printf("Signal+background SE: %s",hs_name.Data());
       
     if (useEM){
       TH1D * hb1 = (TH1D*) f->Get(hb1em_name.Data())->Clone();
       Printf("Background em 1: %s",hb1em_name.Data());
       TH1D * hb2 = (TH1D*) f->Get(hb2em_name.Data())->Clone();
       Printf("Background em 2: %s",hb2em_name.Data());
       TH1D * hb =  (TH1D*)hb1->Clone();
       hb->Add(hb2,1);
       hb->Scale(0.5);
       //normalize background
       TH1D * hb_norm = normValuesInterval(hb, hs, 1.1, 1.5, 1.);
       hb_norm->SetName(Form("norm_%s",hb->GetName()));
       //draw
       cdisplay->cd(iptbin+1);
       hs->Draw();
       HistoMakeUp(hb);
       HistoMakeUp(hb_norm);     
       hb_norm->Draw("same"); //draw normalized
     } else {
       TH1D * hb1 = (TH1D*) f->Get(hb1ls_name.Data())->Clone();
       Printf("Background ls 1: %s",hb1ls_name.Data());
       TH1D * hb2 = (TH1D*) f->Get(hb2ls_name.Data())->Clone();
       Printf("Background ls 2: %s",hb2ls_name.Data());
       TH1D * hb = (TH1D*) hb1->Clone();
       hb->Add(hb2,1);
       hb->Scale(0.5);
       //normalize background
       TH1D * hb_norm = normValuesInterval(hb, hs, 1.1, 1.5, 1.);
       hb_norm->SetName(Form("norm_%s",hb->GetName()));
       //draw
       cdisplay->cd(iptbin+1);
       hs->Draw();
       HistoMakeUp(hb);
       HistoMakeUp(hb_norm);     
       hb->Draw("same");
       hb_norm->Draw("same"); //draw normalized
     }
     cdisplay->Update();  
  }
  if (useEM) cdisplay->SaveAs(Form("centrality%02i_EM_distribCanvas.root",icentbin));
  else  cdisplay->SaveAs(Form("centrality%02i_LS_distribCanvas.root",icentbin));
  return;
}

/*****************************************/
void showDistributionsPerPtBin(Int_t iptbin=-1,Bool_t useEM=0){
  
  TFile * f= TFile::Open("proj_analysisAOD.root");
  gROOT->LoadMacro("subtractKStarBackgnd.C");
  
  TCanvas * cdisplay = new TCanvas("cdisplay","cdisplay",800,600);
  cdisplay->Divide(3,2);
  
  for (Int_t icentbin=0;icentbin<6;icentbin++){
    TString hs_name=Form("Data_UnlikePM_ptBin%02i_centBin%02i",iptbin,icentbin);
    TString hb1em_name=Form("Data_MixingPM_ptBin%02i_centBin%02i",iptbin,icentbin);
    TString hb2em_name=Form("Data_MixingMP_ptBin%02i_centBin%02i",iptbin,icentbin);
    TString hb1ls_name=Form("Data_LikePP_ptBin%02i_centBin%02i",iptbin,icentbin);
    TString hb2ls_name=Form("Data_LikeMM_ptBin%02i_centBin%02i",iptbin,icentbin);
     
    TH1D * hs = (TH1D*) f->Get(hs_name.Data())->Clone();
    Printf("Signal+background SE: %s",hs_name.Data());
       
     if (useEM){
       TH1D * hb1 = (TH1D*) f->Get(hb1em_name.Data())->Clone();
       Printf("Background em 1: %s",hb1em_name.Data());
       TH1D * hb2 = (TH1D*) f->Get(hb2em_name.Data())->Clone();
       Printf("Background em 2: %s",hb2em_name.Data());
       TH1D * hb =  (TH1D*)hb1->Clone();
       hb->Add(hb2,1);
       hb->Scale(0.5);
       //normalize background
       TH1D * hb_norm = normValuesInterval(hb, hs, 1.1, 1.5, 1.);
       hb_norm->SetName(Form("norm_%s",hb->GetName()));
       //draw
       cdisplay->cd(icentbin+1);
       hs->Draw();
       HistoMakeUp(hb);
       HistoMakeUp(hb_norm);     
       hb_norm->Draw("same"); //draw normalized
     } else {
       TH1D * hb1 = (TH1D*) f->Get(hb1ls_name.Data())->Clone();
       Printf("Background ls 1: %s",hb1ls_name.Data());
       TH1D * hb2 = (TH1D*) f->Get(hb2ls_name.Data())->Clone();
       Printf("Background ls 2: %s",hb2ls_name.Data());
       TH1D * hb = (TH1D*) hb1->Clone();
       hb->Add(hb2,1);
       hb->Scale(0.5);
       //normalize background
       TH1D * hb_norm = normValuesInterval(hb, hs, 1.1, 1.5, 1.);
       //draw
       cdisplay->cd(icentbin+1);
       hs->Draw();
       HistoMakeUp(hb);
       HistoMakeUp(hb_norm);
       hb->Draw("same");
       hb_norm->Draw("same");
     }
     cdisplay->Update();  
  }
  if (useEM) cdisplay->SaveAs(Form("pT%02i_EM_distribCanvas.root",iptbin));
  else cdisplay->SaveAs(Form("pT%02i_LS_distribCanvas.root",iptbin));
  return;
}
