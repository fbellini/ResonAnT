//
// Splits a TH2F using the myHistSplig_sparse_IM_PT_CENT class
//
Bool_t kComputeEfficiency=kFALSE;
const Int_t kNhistosData=6;
TString macroDir ="/Users/bellini/alice/macro/kstar";

void projectKStar
(
   const char *nameData = "analysisAOD.root",
   const char *outName  = "allpT_kstar.root",
   const char *listName = "RsnOut"
)
{
   // initial setup
  gStyle->SetOptStat("1111");
  gStyle->SetTextFont(42);

   // load utility macro
  gROOT->LoadMacro(Form("%s/projectorInvMass_Centrality_Pt.C+g",macroDir.Data()));
   
   //output file
   TFile *fout = TFile::Open(outName, "RECREATE");
   // output list
   TList *out = new TList();
  
   // open input file
   TFile *fileData;// = 0x0;//, *fileMC = 0x0;
   TList *listData;// = 0x0;//, *listMC = 0x0;
   fileData = TFile::Open(nameData);
   if (fileData && fileData->IsOpen()) listData = (TList*)fileData->Get(listName);
   
   // names of computed histograms (one per settings)
   THnSparse* hInput[kNhistosData]= {0,0,0,0,0,0};
   if (listData) {
      hInput[ 0] = (THnSparse*)listData->FindObject("RSN_kstar_UnlikePM");
      hInput[ 1] = (THnSparse*)listData->FindObject("RSN_kstar_UnlikeMP");
      hInput[ 2] = (THnSparse*)listData->FindObject("RSN_kstar_MixingPM");
      hInput[ 3] = (THnSparse*)listData->FindObject("RSN_kstar_MixingMP");
      hInput[ 4] = (THnSparse*)listData->FindObject("RSN_kstar_LikePP");
      hInput[ 5] = (THnSparse*)listData->FindObject("RSN_kstar_LikeMM");
      
      // rename
      hInput[ 0]->SetName("Data_UnlikePM");
      hInput[ 1]->SetName("Data_UnlikeMP");
      hInput[ 2]->SetName("Data_MixingPM");
      hInput[ 3]->SetName("Data_MixingMP");
      hInput[ 4]->SetName("Data_LikePP");
      hInput[ 5]->SetName("Data_LikeMM");
   }
     
   // define binning in pT    
   /* use binning as for phi */
   // Double_t pt[] = {-1., 1.0, 10.0};
   Double_t pt[] = {0.0, 0.50, 1.00, 1.50, 2.00, 2.50, 3.00, 3.5, 4.00, 4.5, 5.0, 6.0, 7.0, 10.00 };
   //Double_t pt[] = {0.0, 0.50, 1.00, 1.25, 1.50, 1.75, 2.00, 2.25, 2.50, 2.75, 3.00, 3.5, 4.00, 4.5, 5.0, 6.0, 7.0, 10.00 };
   //Double_t pt[] = {0.00, 0.50, 1.00, 1.25, 1.50, 1.75, 2.00, 2.25, 2.50, 2.75, 3.00, 3.25, 3.5, 3.75, 4.00, 4.5, 5.00, 5.5, 6.0, 7.0, 10.00 };
   Int_t   npt  = sizeof(pt) / sizeof(pt[0]) - 1;
   
   //define binning in centrality
   //Double_t cent[]={ 0.0, 80.0, 100.0};
   Double_t cent[]={ 0.0, 20.0, 40.0, 60.0, 80.0, 90.0};   
   Int_t   ncent  = sizeof(cent) / sizeof(cent[0]) - 1;
 
     // split histograms
   projectorInvMass_Centrality_Pt projector;
   
   // loop on inputs
   for (Int_t i = 0; i < kNhistosData; i++) {
     if (!hInput[i]) continue;
     // projector.SetPrefix(hInput[i]->GetName());
     // projector.MultiProj(npt, pt, hInput[i], out);
     projector.SetPrefix(hInput[i]->GetName());
     projector.MultiProjPtCent(npt, pt, ncent, cent,  hInput[i], out);

   }
   
   // save into a file
   fout->cd();   
   // write an axis to reproduce the binning
   TAxis *ptbins = new TAxis(npt, pt);
   TAxis *centbins = new TAxis(ncent, cent);
   ptbins->Write("ptbins");
   centbins->Write("centbins");
   // write the list
   out->Write();
   
   // the end
   fout->Close();
   
   return;

}

