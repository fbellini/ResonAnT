#include "TCanvas.h"
#include "RooPlot.h"
using namespace RooFit;

//define binning in centrality
Double_t cent[]={ 0.0, 20.0, 40.0, 60.0, 80.0, 90.0};
Int_t ncent  = sizeof(cent) / sizeof(cent[0]) - 1;

enum EbackgndType{ kUnlikeSE, kUnlikeME,  kLikeSE, knBackgndTypes};


//define binning in invariant mass
const Int_t nbins = 90;
const Double_t pdgMass = 0.89166;
const Double_t pdgWidth = 0.0508;

Double_t xrangem, xrangeM;
Float_t  nWidthRangeFit;
Double_t fitCutMassMin,fitCutMassMax,fitCutWidthMin, fitCutWidthMax;

//gROOT->SetStyle("Plain");
gSystem->Load("libRooFit");

//--------------------------------------------------
void SetFitParams(
		  Double_t massRangeMin = 0.8,
		  Double_t massRangeMax = 1.1,
		  Float_t nWidthRangeMassFit=10.0, 
		  Float_t cutMassMin=-1.0,
		  Float_t cutMassMax=-1.0,
		  Float_t cutWidthMin=-1.0,
		  Float_t cutWidthMax=-1.0
		  ){
  xrangem = massRangeMin;
  xrangeM = massRangeMax;
  nWidthRangeFit= nWidthRangeMassFit;
 
  if (cutMassMin<0.) fitCutMassMin=pdgMass-nWidthRangeFit*pdgWidth;
  else fitCutMassMin=cutMassMin;
  
  if (cutMassMax<0.)  fitCutMassMax=pdgMass+nWidthRangeFit*pdgWidth;
  else fitCutMassMax=cutMassMax;
  
  if (fitCutWidthMin<0) fitCutWidthMin=pdgWidth-0.010;
  else fitCutWidthMin=cutWidthMin;
  
  if (fitCutWidthMax<0) fitCutWidthMax=pdgWidth+0.010;
  else fitCutWidthMax=cutWidthMax;
 
  CheckFitRanges();
  
  return;
}

//--------------------------------------------------
void fitKStar_MultiCentBins(TString infilename="sumKAntiK_subAllPt_proj_analysisAOD.root",Int_t backgndType=EbackgndType::kUnlikeME){
  
  gROOT->LoadMacro("/Users/bellini/alice/macro/SetGraphicStyle.C");
  SetGraphicStyle();

  if (!infilename){
    printf("ERROR: invalid file name provided. \n");
    return;
  }

  TString fileout="";
  if (backgndType==EbackgndType::kUnlikeME){
    fileout.Form("fitEM_%s",infilename.Data());
  } 
  if (backgndType==EbackgndType::kLikeSE){
    fileout.Form("fitLS_%s",infilename.Data());
  } 
  
  TFile * fout=new TFile(fileout.Data(),"recreate");
  Float_t fitParams[7];
  Int_t centBinID;
  TTree *tree=new TTree("tree","fit parameters tree");
  tree->Branch("signalMass",&fitParams[0],"signalMass/F");
  tree->Branch("signalMassErr",&fitParams[1],"signalMassErr/F");
  tree->Branch("signalWidth",&fitParams[2],"signalWidth/F");
  tree->Branch("signalWidthErr",&fitParams[3],"signalWidthErr/F");
  tree->Branch("nSignal",&fitParams[4],"nSignal/F");
  tree->Branch("nBack",&fitParams[5],"nBack/F");
  tree->Branch("chi2",&fitParams[6],"chi2/F");
  
  tree->Branch("centBin",&centBinID,"centBin/I");
  
  TH2F*hMassVsCent=new TH2F("hMassVsCent","Fitted K* mass Vs Centrality;centrality (%);M (GeV/c^{2})",6, 0.,6.,350, 0.75,1.1);
  TH1F*hMassVsCent2=new TH1F("hMassVsCent2","Fitted K* mass Vs Centrality;centrality (%);M (GeV/c^{2})",6, 0.,6.);
  
  TCanvas *cfit=new TCanvas("cfit","cfit", 900,700);
  cfit->Divide(3,2);
  RooPlot *plotframe;
  TString centBinLabel;
  
  for (Int_t icentbin=0; icentbin<ncent;icentbin++){    
    cfit->cd(icentbin+1);
    centBinID=icentbin;
    plotframe=(RooPlot*)fitKStar(icentbin,infilename,backgndType,fitParams);
    hMassVsCent->Fill(icentbin,fitParams[0]);
    hMassVsCent2->SetBinContent(icentbin+1,fitParams[0]);
    hMassVsCent2->SetBinError(icentbin+1,fitParams[1]);
    centBinLabel.Form("%2.0f-%2.0f",cent[icentbin],cent[icentbin+1]);
    hMassVsCent2->GetXaxis()->SetBinLabel(icentbin+1,centBinLabel.Data());
    plotframe->Draw(); 
    tree->Fill();
    }
  fout->cd();
  tree->Write();
  hMassVsCent->Write();
  hMassVsCent2->Write();
  
  fout->Close();

  printf("**************************************************************\n
************************ SUMMARY *****************************\n
Resonance PDG params:
                   pdgMass = %6.5f \n
                   pdgWidth = %6.5f \n
range of S+B fit:
                   xrangem = %6.2f \n
                   xrangeM = %6.2f \n
range of S mass fit:
                   nWidthRangeFit = %6.3f \n
                   fitCutMassMin  = %6.3f \n
                   fitCutMassMax  = %6.3f \n
                   fitCutWidthMin = %6.3f \n
                   fitCutWidthMax = %6.3f \n ", 
	   pdgMass, pdgWidth, xrangem, xrangeM, nWidthRangeFit,
	 fitCutMassMin, fitCutMassMax, fitCutWidthMin,fitCutWidthMax);
  
  return;
}

//------------------------------------------------------------------------------------------------
RooPlot* fitKStar(Int_t icentbin=1,TString infilename="sumKAntiK_subAllPt_proj_analysisAOD.root",Int_t backgndType=EbackgndType::kUnlikeME,Float_t *fitParams=NULL){
  
  /*
    performs fit on K* plots in specified centrality bin 
    from infilename
    where it is assumed that already (norm+)subtracted distributions are given as input
  */

  gROOT->LoadMacro("/Users/bellini/alice/macro/SetGraphicStyle.C");
  SetGraphicStyle();

   TString testopt;
   testopt.Form(" - all p_{T} - ");

  TString testocent;
  testocent.Form("Centrality %2.0f - %2.0f ",cent[icentbin],cent[icentbin+1]);

  char cutstring[100];
  sprintf(cutstring,"");
   
  TFile* fin=TFile::Open(infilename.Data());
  if (!fin) {
    printf("ERROR: invalid or corrupted input file. Exiting.\n");
    return;
  }
  
  if (!infilename){
    printf("ERROR: invalid file name provided. \n");
    return;
  }

  TString testoback="";
  TString hSignalName="";
  if (backgndType==EbackgndType::kUnlikeME){
    hSignalName.Form("subEM_",icentbin);
    testoback.Form("(EM backgnd)");
  }
  if (backgndType==EbackgndType::kLikeSE){
    hSignalName.Form("subLS_",icentbin);
    testoback.Form("(LS backgnd)");
  }
  
  TH1D *hnsig = (TH1D* )fin->Get(hSignalName.Data());
  if (!hnsig){
    printf("fitKstar - ERROR: input histogram %s not found in file %s . returning...\n", hSignalName.Data(),infilename.Data() );
    return;
  }
  
   
  SetFitParams();
  
  Float_t signalMass,signalMassErr,
    signalWidth,signalWidthErr,
    chi2;
  Int_t nrange = 0;
  Int_t nBack=0;
  Int_t nSignal=0;
  
  RooRealVar x("m","M (GeV/c^{2})",xrangem,xrangeM);
  RooRealVar width("width","width",pdgWidth,fitCutWidthMin,fitCutWidthMin);
  RooRealVar mean("mean","mean",pdgMass,fitCutMassMin,fitCutMassMax);
  RooBreitWigner breit("breit","signal Breit-Wigner",x,mean,width);
  RooDataHist data("data","data",RooArgList(x),hnsig);

  /* residual background 1 - Chebychev polynomial */

  RooRealVar c0("c0","coefficient #0", -1.,1.) ;
  RooRealVar c1("c1","coefficient #1", -10.,10.) ;
  RooRealVar c2("c2","coefficient #2", -10.,10.) ;
  RooRealVar c3("c3","coefficient #3", -10.,10.) ;
  RooRealVar c4("c4","coefficient #4", -10.,10.) ;
  RooRealVar c5("c5","coefficient #5", -10.,10.) ;
  RooRealVar c6("c6","coefficient #6", -10.,10.) ;

  RooChebychev cheby("cheby","residual background Chebychev poli", x, RooArgList(c0));//,c1,c2,c3,c4,c5,c6)) ;
  
  /* residual background 2 - Landau */
  RooRealVar sigmaL("sigmaL","Landau sigma",-10.,10.);
  RooRealVar meanL("meanL","Landau mean", -10.,10.);  
  RooLandau landau("landau","residual background Landau",x,meanL,sigmaL);

  /* residual background 3 - exponential */
  // RooRealVar pare("pare","par expo ",-10.,10.);
  // RooExponential expo("expo","residual background exponential",x,pare);
  
  /* method 1: use fraction of signal w.r.t. S+B */
  // model(x) = fsig*sig(x) + (1-fsig)*bkg(x)
  //RooRealVar fsig(“fsig","signal fraction",0.5,0.,1.) ;
  //RooAddPdf model(“model","model",RooArgList(breit,cheby),fsig) ;

  /* method 2: use counts of signal and backgnd */
  RooRealVar nsig("nsig","signal fraction",0.,1E7.) ;
  RooRealVar nbkg("nbkg","background fraction",0.,1E7.) ;
  RooAddPdf model("model","model",RooArgList(breit,cheby),RooArgList(nsig,nbkg)) ;
  
  // a la STAR
  model.fitTo(data, Extended(kTRUE),SumW2Error(kFALSE)) ;
    
  RooPlot* xframe = x.frame() ;
  data.plotOn(xframe,ErrorType(RooAbsData::SumW2)) ;
  model.plotOn(xframe, LineColor(kBlue)) ;
  
  // model.plotOn(xframe, Components(expo),LineStyle(kDashed),LineColor(kRed)) ;
  //model.plotOn(xframe, Components(landau),LineStyle(kDashed),LineColor(kGreen)) ;
  model.plotOn(xframe, Components(cheby),LineStyle(kDashed),LineColor(kRed)) ;
  
  signalMass=mean.getVal();
  signalMassErr=mean.getError();
  signalWidth=width.getVal() ;
  signalWidthErr=width.getError() ;
  nSignal=nsig.getVal();
  nBack=nbkg.getVal();
  chi2=0.;// xframe->chiSquare("model", "data", 3);
  if (fitParams){
    fitParams[0]=signalMass;
    fitParams[1]=signalMassErr;
    fitParams[2]=signalWidth;
    fitParams[3]=signalWidthErr;
    fitParams[4]=nSignal;
    fitParams[5]=nBack;
    fitParams[6]=chi2;
  }
  
  TString frameTitle="K*+#bar{K*}";
  frameTitle.Append(testoback);
  frameTitle.Append(testopt);
  frameTitle.Append(testocent);
  xframe->SetTitle(frameTitle);
  xframe->Draw() ; 
  //return 0;
  //  fin->Close();
  return xframe;
}

//--------------------------------------------------
void CheckFitRanges(){
  
  if (fitCutMassMin < xrangem) {
    fitCutMassMin=xrangem;
  }
  if (fitCutMassMax<xrangeM) {
    fitCutMassMax=xrangeM;
  }
  return;
}
